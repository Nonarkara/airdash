Corrected preprint v2, 4 November 2026. Not peer reviewed; all-author approval pending.
Rebuild PDF: extract this archive, then run python3 build.py (Python 3, pdflatex required).
Frozen JSON summaries, selected extracts, reference metadata, preamble and figure PDFs are included.
The provided figures allow PDF rebuilding without Matplotlib or the original fonts.
Figure regeneration additionally requires the repository public/fonts assets and Python plotting dependencies.
Full statistical extraction is NOT independently reproducible from this archive: scripts still need
unreleased live/archive databases and operational logs. Do not run analysis/run_all.py expecting a frozen replay.
Version 2 withdraws invalid daily alert rates and simulated delivery latency; see CORRECTIONS.md.
