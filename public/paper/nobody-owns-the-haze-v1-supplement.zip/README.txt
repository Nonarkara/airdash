Supplement to 'Nobody owns the haze' (v1, 4 November 2026).
data/*.json      every number and figure input in the paper (frozen 2026-11-04 00:00 Bangkok time)
analysis/*.py    the scripts that produce data/ from the AirDash database and archive
refs/refs.json   the verified reference list; refs/entries.jsonl records what each source says
Rebuild: python3 paper/build.py   (https://github.com/Nonarkara/airdash, folder paper/)
